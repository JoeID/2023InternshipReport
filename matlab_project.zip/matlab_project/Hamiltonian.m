function ham = Hamiltonian(M1, M2, N)

% This function computes the Hamiltonian :
% - M1 : 1-qubit interaction matrix
% - M2 : 2-qubits interaction matrix
% - N : nb of particles

assert(N >= 2);

if N == 2
    ham = kron(M1, eye(2)) + kron(eye(2), M1) + M2;
else
    ham_prec = Hamiltonian(M1, M2, N - 1);
    ham = kron(ham_prec, eye(2)) + kron(eye(pow2(N - 2)), M2) + kron(eye(pow2(N - 1)), M1);
end
