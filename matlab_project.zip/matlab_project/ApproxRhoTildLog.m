function res = ApproxRhoTildLog(M, N)

% returns the 1-norm of rho - rhoTild for interaction M with N particles in
% chunks of 3 particles

assert(floor(log2(N / 3)) == log2(N / 3)); % N/3 must be a power of two

rho = GibbsState(Hamiltonian([0 0; 0 0], M, N));
DIM = zeros(1, N / 3) + 8;
rhoTild = RhoTildLog(rho, 1, N / 3, DIM);

res = SchattenNorm(rho - rhoTild, 1);