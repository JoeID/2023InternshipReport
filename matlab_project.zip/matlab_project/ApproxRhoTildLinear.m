function res = ApproxRhoTildLinear(M, N)

% returns the 1-norm of rho - rhoTild for interaction M with N particles in
% chunks of 3 particles

rho = GibbsState(Hamiltonian([0 0; 0 0], M, N));
rhoTild = eye(pow2(N));
DIM = zeros(1, N / 3) + 8;

for i = 1 : N / 3 - 1
    rhoTild = rhoTild * RhoPart(rho, i, i+1, DIM);
    if i < N / 3 - 1
        rhoTild = rhoTild / RhoPart(rho, i+1, -1, DIM);
    end
end

res = SchattenNorm(rho - rhoTild, 1);