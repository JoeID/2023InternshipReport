function rho_part = RhoPart(rho, i, j, DIM)

% returns the partial rho on subsystems i and j
% DIM is the array of dimensions
% the result is expressed in the whole system ABC

assert((j == i+1) | (j == -1));

new_SYS = 1:length(DIM);

new_SYS(i) = []; % remove i and j from array
if j ~= -1
    new_SYS(i) = []; % the new index of j is i
end

rho_part = TrX(rho, new_SYS, DIM);


if j == -1
    % tracing on single subsystem i
    if i - 1 >= 1
        rho_part = kron(eye(pow2(3 * (i - 1))), rho_part);
    end
    if length(DIM) - i >= 1
        rho_part = kron(rho_part, eye(pow2(3 * (length(DIM) - i))));
    end
else
    % tracing on double subsystem i, i+1
    if i - 1 >= 1
        rho_part = kron(eye(pow2(3 * (i - 1))), rho_part);
    end
    if length(DIM) - (i + 1) >= 1
        rho_part = kron(rho_part, eye(pow2(3 * (length(DIM) - (i + 1)))));
    end
end
