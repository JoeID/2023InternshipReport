function res = ApproxABC(M, m)

% returns the 1-norm of rhoABC - rhoAB*rhoB-1*rhoBC

rho = GibbsState(Hamiltonian([0 0; 0 0], M, m + 6));

rhoAB = kron(TrX(rho, 3, [8 pow2(m) 8]), eye(8));
rhoBC = kron(eye(8), TrX(rho, 1, [8 pow2(m) 8]));
rhoB = kron(eye(8), kron(TrX(rho, [1 3], [8 pow2(m) 8]), eye(8)));

rhoTild = rhoAB / rhoB * rhoBC;

res = SchattenNorm(rhoTild - rho, 1);