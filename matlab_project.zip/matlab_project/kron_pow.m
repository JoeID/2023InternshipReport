function res = kron_pow(M, n)

% returns M kron M ... n times

if(n <= 0)
    res = [1 0; 0 1]; % res is identity
else
    res = M;
    for i=2:n
        res = kron(res, M);
    end
end