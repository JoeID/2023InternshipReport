function rho = GibbsState(H)

% returns the Gibbs state associated with the given Hamiltonian

rho = expm(-H);
rho = rho / trace(rho);
