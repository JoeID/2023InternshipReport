function res = RhoTildLog(rho, start, finish, DIM)

% Returns the approximation using recursive approach

n = finish - start + 1;
assert(floor(log2(n)) == log2(n)); % n must be a power of two

if(n == 2)
    res = RhoPart(rho, start, finish, DIM);
else
    midLeft = start + n / 2 - 1;
    midRight = start + n / 2;

    resLeft = RhoTildLog(rho, start, midLeft, DIM);
    resLeft = resLeft / RhoPart(rho, midLeft, -1, DIM);

    resRight = RhoTildLog(rho, midRight, finish, DIM);
    resRight = resRight / RhoPart(rho, midRight, -1, DIM);

    res = resLeft * resRight * RhoPart(rho, midLeft, midRight, DIM);
end