function res = ApproxRhoTild(M, N)

% returns the 1-norm of rho - rhoTild for interaction M with N particles

rho = GibbsState(Hamiltonian(M, N));
res = 
